let points = parseInt(localStorage.getItem("points")) || 0;
document.getElementById("points").innerText = points;

Telegram.WebApp.ready();
const tgUser = Telegram.WebApp.initDataUnsafe.user;
if (tgUser) {
  document.getElementById("user-first-name").innerText = tgUser.first_name;
  document.getElementById("user-username").innerText = '@' + tgUser.username;
  document.getElementById("user-profile-pic").src = tgUser.photo_url || "https://cdn-icons-png.flaticon.com/512/3135/3135715.png";
}

document.querySelectorAll(".ad-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    btn.disabled = true;
    const zone = btn.dataset.zone;
    const script = document.createElement("script");
    script.src = `//jagnaimsee.net/vignette.min.js`;
    script.setAttribute("data-zone", zone);
    document.body.appendChild(script);
    setTimeout(() => {
      points += 500;
      localStorage.setItem("points", points);
      document.getElementById("points").innerText = points;
      btn.disabled = false;
    }, 9000);
  });
});
