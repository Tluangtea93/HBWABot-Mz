let tg = window.Telegram.WebApp;
tg.expand();

let points = localStorage.getItem('points') ? parseInt(localStorage.getItem('points')) : 0;
document.getElementById("points").innerText = points;

document.getElementById("user").innerText = "Hello, " + tg.initDataUnsafe.user.first_name;

function watchAd() {
  points += 500;
  localStorage.setItem('points', points);
  document.getElementById("points").innerText = points;
}